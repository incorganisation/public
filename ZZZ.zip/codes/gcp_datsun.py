


import random
import selenium
import os

from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle



def traffic_bot(S,BR,PS,TOS,sleep,LP,urls,cName,fName):
    usr_agnt_desktop=[
"Mozilla/5.0 (BB10; Touch) AppleWebKit/537.35+ (KHTML, like Gecko) Version/10.3.2.2876 Mobile Safari/537.35+",
"Mozilla/5.0 (BB10; Kbd) AppleWebKit/537.35+ (KHTML, like Gecko) Version/10.3.2.2876 Mobile Safari/537.35+",
"Mozilla/5.0 (Linux; U; Android 4.3; en-gb; GT-I9300 Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E277 Safari/602.1",
"Mozilla/5.0 (Linux; Android 5.0.1; SAMSUNG GT-I9515 Build/LRX22C) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 7.0; LGMS210 Build/NRD90U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; LGMS659 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-G920P Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.2 Chrome/38.0.2125.102 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.3.6; pt-br; GT-S6102B Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (iPhone; CPU iPhone OS 9_0_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13A405 Safari/601.1",
"Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13F69",
"Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19",
"Mozilla/5.0 (iPhone; CPU iPhone OS 5_0_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A405 Safari/7534.48.3",
"Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; LS670 Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; LGMS323 Build/KOT49I.MS32310c) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.1599.103 Mobile Safari/537.36",
"Mozilla/5.0 (BB10; Touch) AppleWebKit/537.10+ (KHTML, like Gecko) Version/10.1.0.2342 Mobile Safari/537.10+" 
    ]
    for i in range(0,1):
        f=open(fName,'a')
        f.write("---------------------------------INSTANCE REBOOTED-----------------------------------\n")
        f.flush()
#-------------------------------change chrome UA------------------------------
        opts = Options()
        ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,160)) + '.zip'
        opts.add_extension(ext)

        opts.add_argument("user-agent="+ usr_agnt_desktop[randint(0,len(usr_agnt_desktop)-1)])

#---------------------------------change firefox UA------------------------------
#        profile = webdriver.FirefoxProfile()
#        profile.set_preference("general.useragent.override",usr_agnt_desktop[randint(0,len(usr_agnt_desktop)-1)])
#----------------------------------------- 0 BR code---------------------------------
        a=0;
        time_cookiearray=[];
        zero_ps=((100*PS-BR)/(100-BR))-1
        zero_tos=(TOS*100)/(100-BR)
        while(a<((S*(100-BR))/100) or len(time_cookiearray)>0):
            driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver',chrome_options=opts)
            # driver.set_window_size(360,640)
            if(a<(S*(100-BR))/100):
                driver.get(LP);
                time.sleep(sleep);
                if (a%3!=0):
                    driver.get(driver.current_url);
                    time.sleep(sleep);
                    driver.get(driver.current_url);
                    time.sleep(sleep);
                    driver.get(driver.current_url);
                    time.sleep(sleep);
#               driver.get_screenshot_as_file('google.png')
                time0=datetime.datetime.now();
                cookie0=cName+str(a)+".pkl" ;
                curl0=driver.current_url
                f.write('Count %s,Initial_0Br,%s\n'% (a,str(datetime.datetime.now())))
                f.flush()
                time_cookiearray.append((time0,cookie0,curl0))
                pickle.dump(driver.get_cookies(),open(cookie0,"wb"))
                driver.delete_all_cookies()
#-----------RESTORE COOKIE FOR PREV SESSION-------------------
            if((datetime.datetime.now()-time_cookiearray[0][0]).seconds>zero_tos):
                cookies = pickle.load(open(time_cookiearray[0][1],"rb"))
                for cookie in cookies:
                    new_cookie={}
                    new_cookie['name']=cookie['name']
                    new_cookie['value']=cookie['value']
                    driver.add_cookie(new_cookie)
#----------------------------OPEN LINKS FOR OLD PS-----------------------------
                for pss in range(zero_ps):
                    driver.get(time_cookiearray[0][2]);
                    time.sleep(sleep)
                f.write('Count %s,Final_0Br,%s\n'% (a,str(datetime.datetime.now())))
                f.flush()
#----------------------------DELETE USED COOKIE-------------------------------
                os.remove(time_cookiearray[0][1])
                del time_cookiearray[0];
                driver.delete_all_cookies();
            driver.close();
            driver.quit();
            a=a+1;
#---------------------------------100 BR code-------------------------------
        for a in range(0,(S*BR)/100):
            driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver',chrome_options=opts)
            # driver.set_window_size(360,640)
            driver.delete_all_cookies();
            driver.get(LP);
            time.sleep(sleep);
            f.write('Count %s,Only_100Br,%s\n'% (a,str(datetime.datetime.now())));
            f.flush();
            driver.delete_all_cookies();
            driver.close();
            driver.quit();
#-----------------------Delete faaltu cookies-------------------------
        while (len(time_cookiearray)>0):
            try:
                os.remove(time_cookiearray[0][1]);
                del time_cookiearray[0];
            except:
                continue

utm=""
url="https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=414;d=20;w=1;h=1"  #to be changed
iteration=str(randint(0,100))
linking=[url,url,url,url,url]


while(True):

    traffic_bot(200,30,3,60,1,url,linking,"cookies_"+iteration+"_","tc_"+iteration+".csv")   #   to change the data
