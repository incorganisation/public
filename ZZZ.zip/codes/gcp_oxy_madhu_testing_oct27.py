""" {
    "device": "mob",
    "proxy": "nne",
    "url": "http://xp2.zedo.com/jsc/xp2/ff2.html?n=3711;c=0;d=20;w=1;h=1",
    "path": "/home/adops_increvenue_com/chromedriver",
    "codename": "gcp_oxy_madhu_testing_oct27",
    "ig_no": 24,
    "cap": 410001,
    "packet_size": 200,
    "br_kpi": 30,
    "ps_kpi": 2,
    "tos_kpi": 150,
    "st": 0,
    "et": 2359,
    "sd": "2018-10-10",
    "ed": "2018-10-31",
    "logging":"off",
    "oxy_range": [
        {
            "start": 1,
            "end": 40
       },
       {
            "start": 41,
            "end": 80
       },
       {
            "start": 81,
            "end": 130
       }          
  ]
} """
import random
import selenium
import os

from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle



def traffic_bot(S,BR,PS,TOS,sleep,LP,urls,cName,fName,path):

    