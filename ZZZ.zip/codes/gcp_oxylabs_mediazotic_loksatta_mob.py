



import random
import selenium
import os

from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle



def traffic_bot(S,BR,PS,TOS,sleep,LP,urls,cName,fName):
    usr_agnt_mobile=[
"Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko; googleweblight) Chrome/38.0.1025.166 Mobile Safari/535.19",
"Mozilla/5.0 (Linux; U; Android 4.0.4; pt-br; MZ608 Build/7.7.1-141-7-FLEM-UMTS-LA) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30",
"Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/LMY48B ) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android-4.0.3; en-us; Galaxy Nexus Build/IML74K) AppleWebKit/535.7 (KHTML, like Gecko) CrMo/16.0.912.75 Mobile Safari/535.7",
"Mozilla/5.0 (Linux; U; Android-4.0.3; en-us; Xoom Build/IML77) AppleWebKit/535.7 (KHTML, like Gecko) CrMo/16.0.912.75 Safari/535.7",
"Mozilla/5.0 (Linux; Android 5.1.1; Nexus 5 Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.65 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.4.2; zh-cn; GT-I9500 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.0 QQ-URL-Manager Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android; 4.1.2; GT-I9100 Build/000000) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1234.12 Mobile Safari/537.22 OPR/14.0.123.123",
"Mozilla/5.0 (Linux; U; Android 2.3.6; en-us; LG-L38C Build/GRK39F) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1 MMS/LG-Android-MMS-V1.0/1.2",
"Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-G360T1 Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.3 Chrome/38.0.2125.102 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG SM-G900T Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.6 Chrome/28.0.1500.94 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.2; fr-fr; Desire_A8181 Build/FRF91) App3leWebKit/53.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; LGMS500 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; LGMS769 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-G550T1 Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/44.0.2403.133 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG-SM-G900A Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.6 Chrome/28.0.1500.94 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 7.0; LGMS210 Build/NRD90U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.3.6; en-gb; GT-S5830i Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; Android 4.4.2; LG-F180L Build/KOT49I.F180L30b) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36"
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG SM-N900T Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.5 Chrome/28.0.1500.94 Mobile Safari/537.36",
    ]
    for i in range(0,1):
        f=open(fName,'a')
        f.write("---------------------------------INSTANCE REBOOTED-----------------------------------\n")
        f.flush()
#-------------------------------change chrome UA------------------------------
        opts = Options()
        # opts.add_argument("headless")
        # opts.add_argument("no-sandbox")
        
        # ext = '/home/adops_increvenue_com/dcoxyzips/' + 'dcoxy' + str(randint(1,50)) + '.zip'
        # ext = 'dcoxy' + str(randint(1,50)) + '.zip'

        # opts.add_extension(ext)

        # ext1 = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,30)) + '.zip'
        # ext2 = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(41,50)) + '.zip'
        # ext = random.choice([ext1,ext2])

        # #ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(41,50)) + '.zip'

        # opts.add_extension(ext)
        ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,160)) + '.zip'
        opts.add_extension(ext)

        # ext1 =  'dcoxy' + str(randint(1,10)) + '.zip'
        # ext2 =  'dcoxy' + str(randint(41,50)) + '.zip'
        # ext = random.choice([ext1,ext2])
        # opts.add_extension(ext)

        opts.add_argument("user-agent="+ usr_agnt_mobile[randint(0,len(usr_agnt_mobile)-1)])

#---------------------------------change firefox UA------------------------------
#        profile = webdriver.FirefoxProfile()
#        profile.set_preference("general.useragent.override",usr_agnt_desktop[randint(0,len(usr_agnt_desktop)-1)])
#----------------------------------------- 0 BR code---------------------------------
        a=0;
        time_cookiearray=[];
        zero_ps=((100*PS-BR)/(100-BR))-1
        zero_tos=(TOS*100)/(100-BR)
        while(a<((S*(100-BR))/100) or len(time_cookiearray)>0):
            driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver',chrome_options=opts)
            driver.set_window_size(360,640)
            if(a<(S*(100-BR))/100):
                driver.get(LP);
                time.sleep(sleep);
#               driver.get_screenshot_as_file('google.png')
                time0=datetime.datetime.now();
                cookie0=cName+str(a)+".pkl" ;
                curl0=driver.current_url
                f.write('Count %s,Initial_0Br,%s\n'% (a,str(datetime.datetime.now())))
                f.flush()
                time_cookiearray.append((time0,cookie0,curl0))
                pickle.dump(driver.get_cookies(),open(cookie0,"wb"))
                driver.delete_all_cookies()
#-----------RESTORE COOKIE FOR PREV SESSION-------------------
            if((datetime.datetime.now()-time_cookiearray[0][0]).seconds>zero_tos):
                cookies = pickle.load(open(time_cookiearray[0][1],"rb"))
                for cookie in cookies:
                    new_cookie={}
                    new_cookie['name']=cookie['name']
                    new_cookie['value']=cookie['value']
                    driver.add_cookie(new_cookie)
#----------------------------OPEN LINKS FOR OLD PS-----------------------------
                for pss in range(zero_ps):
                    driver.get(time_cookiearray[0][2]);
                    time.sleep(sleep)
                f.write('Count %s,Final_0Br,%s\n'% (a,str(datetime.datetime.now())))
                f.flush()
#----------------------------DELETE USED COOKIE-------------------------------
                os.remove(time_cookiearray[0][1])
                del time_cookiearray[0];
                driver.delete_all_cookies();
            driver.close();
            driver.quit();
            a=a+1;
#---------------------------------100 BR code-------------------------------
        for a in range(0,(S*BR)/100):
            driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver',chrome_options=opts)
            driver.set_window_size(360,640)
            driver.delete_all_cookies();
            driver.get(LP);
            time.sleep(sleep);
            f.write('Count %s,Only_100Br,%s\n'% (a,str(datetime.datetime.now())));
            f.flush();
            driver.delete_all_cookies();
            driver.close();
            driver.quit();
#-----------------------Delete faaltu cookies-------------------------
        while (len(time_cookiearray)>0):
            try:
                os.remove(time_cookiearray[0][1]);
                del time_cookiearray[0];
            except:
                continue

utm=""
url="https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=224;d=20;w=1;h=1"  #to be changed
iteration=str(randint(0,100))
linking=[url,url,url,url,url]


while(True):

    traffic_bot(200,30,3,250,1,url,linking,"cookies_"+iteration+"_","tc_"+iteration+".csv")   #   to change the data
