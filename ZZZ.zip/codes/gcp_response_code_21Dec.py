from selenium import webdriver
import requests
import socket
import httplib
import sys
import time
import selenium
import subprocess
import os
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
import time
import datetime
from selenium.common.exceptions import TimeoutException
from requests import ConnectionError
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from random import randint

now = datetime.datetime.now()

iplist = ["167.160.49.2", "167.160.49.5", "167.160.49.8", "167.160.49.11", "167.160.49.14", "167.160.49.17", "167.160.49.20", "167.160.49.23", "167.160.49.26", "167.160.49.29", "167.160.49.32", "167.160.49.35", "167.160.49.38", "167.160.49.41", "167.160.49.44", "167.160.49.47", "167.160.49.50", "167.160.49.53", "167.160.49.56", "167.160.49.59", "167.160.49.62", "167.160.49.65", "167.160.49.68", "167.160.49.71", "167.160.49.74", "167.160.49.77", "167.160.49.80", "167.160.49.83", "167.160.49.86", "167.160.49.89", "167.160.49.92", "167.160.49.98", "167.160.49.101", "167.160.49.104", "167.160.49.110", "167.160.49.113", "167.160.49.116", "167.160.49.119", "167.160.49.122", "167.160.49.125", "167.160.49.128", "167.160.49.131", "167.160.49.134", "167.160.49.137", "167.160.49.140", "167.160.49.143", "167.160.49.146", "167.160.49.149", "167.160.49.152", "167.160.49.155", "167.160.49.158", "167.160.49.161", "167.160.49.164", "167.160.49.167", "167.160.49.170", "167.160.49.173", "167.160.49.176", "167.160.49.179", "167.160.49.182", "167.160.49.185", "167.160.49.188", "167.160.49.194", "167.160.49.197", "167.160.49.200", "167.160.49.209", "167.160.49.212", "167.160.49.215", "167.160.49.218", "167.160.49.221", "167.160.49.224", "167.160.49.227", "167.160.49.230", "167.160.49.233", "167.160.49.236", "167.160.49.239", "167.160.49.242", "167.160.49.245", "167.160.49.248", "167.160.49.251", "167.160.49.254", "167.160.51.2", "167.160.51.5", "167.160.51.8", "167.160.51.14", "167.160.51.17", "167.160.51.23", "167.160.51.26", "167.160.51.29", "167.160.51.32", "167.160.51.38", "167.160.51.41", "167.160.51.44", "167.160.51.47", "160.51.53", "167.160.51.56", "167.160.51.59", "167.160.51.62", "167.160.51.65", "167.160.51.68", "167.160.51.71", "167.160.51.74", "167.160.51.77", "167.160.51.80", "167.160.51.83", "167.160.51.86", "167.160.51.89", "167.160.51.92", "167.160.51.95", "167.160.51.98", "167.160.51.104", "167.160.51.110", "167.160.51.113", "167.160.51.119", "167.160.51.125", "167.160.51.128", "167.160.51.134", "167.160.51.137", "167.160.51.140", "167.160.51.143", "167.160.51.149", "167.160.51.152", "167.160.51.155", "167.160.51.158", "167.160.51.164", "167.160.51.167", "167.160.51.170", "167.160.51.173", "167.160.51.176", "167.160.51.179", "167.160.51.182", "167.160.51.185", "167.160.51.188", "167.160.51.191", "167.160.51.194", "167.160.51.200", "167.160.51.206", "167.160.51.209", "167.160.51.212", "167.160.51.215", "167.160.51.218", "167.160.51.221", "167.160.51.224", "167.160.51.230", "167.160.51.233", "167.160.51.236", "167.160.51.239", "167.160.51.245", "167.160.51.248", "167.160.51.251", "167.160.51.254"]


links = 'https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=290;d=20;w=1;h=1'


def launch_driver(link,i):
	global URL,ts1,ts2
	try:
		opts = Options()
		opts.add_extension('/home/adops_increvenue_com/codes/' + 'dcoxy' + str(i) + '.zip')
		driver = webdriver.Chrome(executable_path="/home/adops_increvenue_com/chromedriver",chrome_options=opts)
		ts1 = time.time()
		driver.get(links)
		ts2 = time.time()
		URL = driver.current_url
		
		def clipurl(url):
                	for i in range(len(url)-1):
                 		if (url[i]=="&" or url[i]=="/" or url[i]==";" or url[i]=="."):
                  			url=url[:i]+"_"+url[i+1:];
                	return url;
		
		#folder_url = clipurl(URL)
	        #os.system("mkdir ~/screenshots/%s"%(folder_url))
                new_url = clipurl(str(iplist[i])+"_"+str(URL)+"_"+str(ts2)+"_"+str(NOI)+'.png')
                driver.get_screenshot_as_file(new_url)
		#os.system("sudo chmod 755 /home/adops_increvenue_com/codes/findfolder.sh")
        	#os.system("sh findfolder.sh %s"%(folder_url))
	
		driver.close()
		return URL,ts1,ts2
	
	except TimeoutException as ex:
			exists = os.path.isfile(filepath)
			if exists:
                		with open(filepath,'a') as f:
					f.write("IP %s exited with timeout exception\n"%iplist[ip])
					f.close() 
			else:
				with open(filepath,'w+') as f:
				    	f.write("IP %s exited with timeout exception \n"%iplist[ip])
					f.close()


def req_hit(url):
	global r,ts3,ts4
	try:
	  URL = url
	  s = requests.Session()
	  s.proxies = proxies
	  ts3 = time.time()
	  r = s.get(URL)
	  ts4 = time.time()
	  return r,ts3,ts4
	except ConnectionError:
	  exists = os.path.isfile(filepath)
          if exists:
#          print("file exists \n")
              with open(filepath,'a') as f:
                    f.write("IP %s exited with request connection error\n"%iplist[ip])
                    f.close() 
          else:
              with open(filepath,'w+') as f:
                    f.write("IP %s exited with request connection error \n"%iplist[ip])
                    f.close()


while True:
	ip = randint(0,len(iplist))
	global NOI
	os.system("""sudo gcloud compute instance-groups managed list --sort-by="~SIZE" > instance_groups.txt""")
	os.system("grep -Eo ' [0-9]{1,4} ' instance_groups.txt >  instances_in_instance_groups.txt")
	total_double_sum = subprocess.check_output("awk '{SUM += $1} END { print SUM }'  instances_in_instance_groups.txt ", shell=True)
	total_double_sum = int(total_double_sum.decode())
	NOI = int(total_double_sum / 2 )
	proxies = {
	'http': 'http://increvenue:8n4taUyjcq@' + iplist[ip] + ':60000',
	'https': 'https://increvenue:8n4taUyjcq@' + iplist[ip] + ':60000', 
	}
	hourwise_file = 'logs_' + str(now.strftime("%Y-%m-%d_%H")) + '.txt'
	filepath = os.path.join('/home/adops_increvenue_com/',hourwise_file )
	time_stamp = now.strftime("%Y-%m-%d %H:%M")
	launch_driver(links,ip+1)
	req_hit(URL)
	status = r.status_code
	driver_timetaken = round(ts2 - ts1)
	res_timetaken = round(ts4 - ts3)
	
		

# pass all the data collected in log files 

	exists = os.path.isfile(filepath)
	if exists:
		with open(filepath,'a') as f:
			f.write("%s	%s	%d	%s	%d	%d	%d \n"%(time_stamp,iplist[ip],status,URL,driver_timetaken,res_timetaken,NOI))
			f.close()
	
	else:
		with open(filepath,'w+') as f:
			f.write("time_stamp	ip	status	URL_bydriver	driver_timetaken	res_timetaken	Number_of_instances \n")
			f.write("%s	%s	%d	%s	%d	%d	%d \n"%(time_stamp,iplist[ip],status,URL,driver_timetaken,res_timetaken,NOI))
			f.close()
