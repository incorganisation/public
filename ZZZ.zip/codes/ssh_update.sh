# This script we use for updating the ssh key in vm. we will copy id_rsa and id_rsa.pub files available in codes folder and paste it in .ssh folder of vm .then we will update same ssh key in azure console and github portal through settings section.

sudo rm -rf .ssh/*
sudo mkdir .ssh
cd .ssh
sudo cp ~/codes/id_rsa  .
sudo cp ~/codes/id_rsa.pub .
sudo chmod 600 id_rsa
exit 0
