import random
import selenium
import os

from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle

path="/home/chromedriver"

def traffic(LP):
    usr_agnt_mobile=[
"Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Mobile/11D257 Twitter for iPhone",
"Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Mobile/11D201 Twitter for iPhone",
"Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Mobile/12F70 Twitter for iPhone",
"Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13F69 Twitter for iPhone",
]


    opts = Options()

    opts.add_argument("user-agent="+ usr_agnt_mobile[randint(0,len(usr_agnt_mobile)-1)]);
    
    driver = webdriver.Chrome(executable_path=path,chrome_options=opts);
    time.sleep(1);
    driver.get(LP);
    time.sleep(2);
    driver.execute_script("window.scrollTo(0, 0)")
    (driver.find_element_by_id("rateit-range-4")).click();
    time.sleep(5)
    driver.close();
    driver.quit();


traffic("https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=548;d=20;w=1;h=1");




