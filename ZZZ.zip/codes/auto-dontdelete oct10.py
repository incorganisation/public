from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle
import glob, os
import subprocess


def inc_s(s,iter):
        if (iter=="initial0" or iter=="only100"):
                s=s+1
        elif (iter=="final0"):
                s=s
        return s
def inc_br(s,br,iter):#iter can be initial0 or final0 or only100
        if (iter=="initial0" or iter=="only100"):
                br=(s*br+100)/float(s+1)
        elif (iter=="final0"):
                br=(s*br-100)/float(s)
        return br
def inc_tos(s,tos,zero_tos,iter):
        if (iter=="initial0" or iter=="only100"):
                tos=(s*tos)/float(s+1)
        elif (iter=="final0"):
                tos=(s*tos+zero_tos)/float(s)
        return tos
def inc_ps(s,ps,zero_ps,iter):
        if (iter=="initial0" or iter=="only100"):
                ps=(s*ps+1)/float(s+1)
        elif (iter=="final0"):
                ps=(s*ps+zero_ps)/float(s)
        return ps
def cliputm(url):
        index=url.find("?")
        if (index==-1):
                return url
        else:
                return url[:index]

def dt():
        return (subprocess.check_output("TZ=Asia/Calcutta date +%Y-%m-%d", shell=True)[:-1],subprocess.check_output("TZ=Asia/Calcutta date +%H:%M:%S", shell=True)[:-1]);

def club_packets(s1,br1,ps1,tos1,s2,br2,ps2,tos2):
    clubbed=[0,0,0,0];
    clubbed[0]=s1+s2;
    if (s1+s2==0): 
        clubbed[1]=0
        clubbed[2]=0
        clubbed[3]=0
    else:
        clubbed[1]=((br1*s1)+(br2*s2))/(s1+s2)
        clubbed[2]=((ps1*s1)+(ps2*s2))/(s1+s2)
        clubbed[3]=((tos1*s1)+(tos2*s2))/(s1+s2)
    return clubbed

def clubfiledata(master,temp):
        club=open(master,'r')
        master_packet=(club.read())[:-1].split(",");        
        club.close();
        filename=open(temp,'r')
        data_packet=(filename.read())[:-1].split(",");
        filename.close();
        final_data=club_packets(float(master_packet[3]),float(master_packet[4]),float(master_packet[5]),float(master_packet[6]),float(data_packet[0]),float(data_packet[1]),float(data_packet[2]),float(data_packet[3]))
        club=open(master,'w')
        club.write('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n'%(IgName,Codename,str(Cap),str(final_data[0]),str(final_data[1]),str(final_data[2]),str(final_data[3]),str(st),str(et),dt()[0],dt()[1],sd,ed,str(cookie_checker)))
        club.close();
        os.remove(temp)



def traffic(Cap,S,BR,PS,TOS,sleep,LP,urls,cName,fName,calc,iteration,Codename,IgName):
    for i in range(0,1):
        #-------------------------------change chrome UA------------------------------
        opts = Options()
        opts.add_argument("no-sandbox")
        # opts.add_argument("user-agent="+ usr_agnt_mobile[randint(0,len(usr_agnt_mobile)-1)])

        #----------------------------------------- 0 BR code---------------------------------
        a=0;
        #this is calc=[a,s,br,ps,tos]
        time_cookiearray=[];
        zero_ps=((100*PS-BR)/(100-BR))-1
        zero_tos=(TOS*100)/(100-BR)
        while(a<((S*(100-BR))/100) or len(time_cookiearray)>0):
            driver = webdriver.Chrome(executable_path=path,chrome_options=opts)
            if(a<(S*(100-BR))/100):
                driver.get(LP);
                time.sleep(sleep);
                calc=[a,inc_s(calc[1],"initial0"),inc_br(calc[1],calc[2],"initial0"),inc_ps(calc[1],calc[3],zero_ps,"initial0"),inc_tos(calc[1],calc[4],zero_tos,"initial0")]
        #               driver.get_screenshot_as_file('session'+str(calc[1])+'.png')
                time0=datetime.datetime.now();
                cookie0=cName+str(a)+".pkl" ;
                print cookie0
                curl0=driver.current_url;
                f=open(fName,'w')
        #               f.write('initial0:-,a,%s,s,%s,br,%s,tos,%s,ps,%s\n'% (str(calc[0]),str(calc[1]),str(calc[2]),str(calc[3]),str(calc[4])))
                f.write('%s,%s,%s,%s\n'% (str(calc[1]),str(calc[2]),str(calc[3]),str(calc[4])))                
                f.flush();
                f.close();
                time_cookiearray.append((time0,cookie0,curl0))
                pickle.dump(driver.get_cookies(),open(cookie0,"wb"))
                driver.delete_all_cookies()
        #-----------RESTORE COOKIE FOR PREV SESSION-------------------
            if((datetime.datetime.now()-time_cookiearray[0][0]).seconds>zero_tos):
                cookies = pickle.load(open(time_cookiearray[0][1],"rb"))
                for cookie in cookies:
                    new_cookie={}
                    new_cookie['name']=cookie['name']
                    new_cookie['value']=cookie['value']
                    try:
                        driver.add_cookie(new_cookie)
                    except:
                        driver.get(cliputm(LP))
                        time.sleep(1)
                        driver.delete_all_cookies()
                        time.sleep(1)
                        driver.add_cookie(new_cookie)                   


        #----------------------------OPEN LINKS FOR OLD PS-----------------------------
                for pss in range(zero_ps):
                    driver.get(time_cookiearray[0][2]);
                    time.sleep(sleep)
                calc=[a,inc_s(calc[1],"final0"),inc_br(calc[1],calc[2],"final0"),inc_ps(calc[1],calc[3],zero_ps,"final0"),inc_tos(calc[1],calc[4],zero_tos,"final0")]
                f=open(fName,'w')
        #               f.write('final0:-,a,%s,s,%s,br,%s,tos,%s,ps,%s\n'% (str(calc[0]),str(calc[1]),str(calc[2]),str(calc[3]),str(calc[4])))
                f.write('%s,%s,%s,%s\n'% (str(calc[1]),str(calc[2]),str(calc[3]),str(calc[4])))                
                f.flush();
                f.close();
        #----------------------------DELETE USED COOKIE-------------------------------
                os.remove(time_cookiearray[0][1])
                del time_cookiearray[0];
                driver.delete_all_cookies();
            driver.close();
            driver.quit();
            f.close();
            a=a+1;
        #-----------------------------------100 BR code-------------------------------
        for a in range(0,(S*BR)/100):
            driver = webdriver.Chrome(executable_path=path,chrome_options=opts)
            driver.delete_all_cookies();
            driver.get(LP);
            calc=[a,inc_s(calc[1],"only100"),inc_br(calc[1],calc[2],"only100"),inc_ps(calc[1],calc[3],zero_ps,"only100"),inc_tos(calc[1],calc[4],zero_tos,"only100")]
            time.sleep(sleep);
            f=open(fName,'w')
        #           f.write('only100:-,a,%s,s,%s,br,%s,tos,%s,ps,%s\n'% (str(calc[0]),str(calc[1]),str(calc[2]),str(calc[3]),str(calc[4])))
            f.write('%s,%s,%s,%s\n'% (str(calc[1]),str(calc[2]),str(calc[3]),str(calc[4])))                
            f.flush();
            f.close();
            driver.delete_all_cookies();
            driver.close();
            driver.quit();
            f.close();
        #---------------------------------Delete faaltu cookies-------------------------
        while (len(time_cookiearray)>0):
            try:
                os.remove(time_cookiearray[0][1]);
                del time_cookiearray[0];
            except:
                continue
        

def campaign(Cap,S,BR,PS,TOS,sleep,LP,urls,Codename,IgName,master_file,st,et,path,sd,ed,cookie_checker): #logs [igname, codename , Cap , S, br , ps tos , st , et , date , time ]        
        reset=open("reset.csv","w");
        reset.write('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n'%(IgName,Codename,str(Cap),str(0),str(0),str(0),str(0),str(st),str(et),dt()[0],dt()[1],sd,ed,str(cookie_checker)));
        reset.close();
        try:
                r= open(master_file,"r");
                r.close();
        except:
                r=open(master_file,"w");
                r.write('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n'%(IgName,Codename,str(Cap),str(0),str(0),str(0),str(0),str(st),str(et),dt()[0],dt()[1],sd,ed,str(cookie_checker)));
                r.close();
#iteration2=str(randint(0,1000))
        while(True):
                iteration=str(randint(0,1000000));
                try:
                        traffic(Cap,S,BR,PS,TOS,2,url,linking,"cookies_"+iteration+"_","calc_"+iteration+".csv",[0,0,0,0,0],iteration,Codename,IgName);
                        time.sleep(1);
                except:
                        print "in error"
                        clubfiledata(master_file,"calc_"+iteration+".csv")
                clubfiledata(master_file,"calc_"+iteration+".csv")

utm=""
url="http://greatlovers942.blogspot.com/?utm_source=37_cloud&utm_medium=37_cloud"
#path='/Users/adityasaraswat/Desktop/increv_rnd/Lovish/chromedriver'
path='/home/adops_increvenue_com/chromedriver';

Codename="gcp_oxy_dh_sept11.py";
IgNo=11;
Cap=10000
st=0
et=2359
cookie_checker=0;
sd="2018-10-10";
ed="2018-10-31";



linking=[url,url,url,url,url]
IgName="group"+str(IgNo);
master_file="master~"+str(Codename)+"~"+IgName+"~"+str(randint(10000,100000))+".csv";

campaign(Cap,5,30,2,4,1,url,linking,Codename,IgName,master_file,st,et,path,sd,ed,cookie_checker);


#logs igname, codename , Cap , S, br , ps tos , st , et 
