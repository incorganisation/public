import random
import selenium
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime

while (True):
    opts = Options()
    opts.add_argument('--no-sandbox');
    driver = webdriver.Chrome(executable_path='/root/chromedriver',chrome_options=opts)
    driver.get("https://bit.ly/2kjyKkd")
    time.sleep(1)
    
    
    
    
