# This script we use for updating the ssh key in vm. we will copy id_rsa.pub file available in codes folder and paste it in authorized_keys of .ssh folder of vm .then we will update same ssh key in azure console and github portal through settings section.

sudo rm -rf ~/.ssh/
sudo mkdir ~/.ssh && cd ~/.ssh/
sudo touch authorized_keys
sudo chown e093fdc2-82f7-4707-9aba-0f67626e:e093fdc2-82f7-4707-9aba-0f67626e authorized_keys
cat ~/codes/id_rsa.pub  >> ~/.ssh/authorized_keys
#sudo chmod 600 authorized_keys
exit 0
