hour=`date -d '1 hour ago' "+%H"`
month=`date -d '1 hour ago' "+%m"`
date=`date -d '1 hour ago' "+%d"`
year=`date -d '1 hour ago' "+%Y"`
logfile='logs_'$year'-'$month'-'$date'_'$hour'.txt'

### Packages required for quickstart installation Run these commands maually

# install required packages
#sudo apt-get install python3-pip
#pip3 install --upgrade google-api-python-client oauth2client



##========================================================================================
### after successfull installation main task starts here

cd
file='screenshots_'$year'_'$month'_'$date'_'$hour

rm -rf /home/adops_increvenue_com/$file
mkdir  /home/adops_increvenue_com/$file
sudo chown adops_increvenue_com:1799668394 /home/adops_increvenue_com/$file
cp  /home/adops_increvenue_com/*_png  /home/adops_increvenue_com/$file
cd /home/adops_increvenue_com/$file
sudo chown adops_increvenue_com:1799668394 *_png 
cd

## upload logs files
cat $logfile >> /home/adops_increvenue_com/codes/logs_responsecode.csv
cd codes
python3 quickstart_uploadlogs.py
cd


### check whether all the files moved to screenshots_timestamp or not
folder=`cat /home/adops_increvenue_com/folderid.txt`

if [[ "$folder" -eq "" ]]
then
rm -rf /home/adops_increvenue_com/folderid.txt 
cd codes
python3 quickstart_createnewFolder.py Global_screenshots
cd
else

for png in `ls /home/adops_increvenue_com/$file/`
do 

## start uploading png one by one 
folder=`cat /home/adops_increvenue_com/folderid.txt`
cp /home/adops_increvenue_com/$file/* /home/adops_increvenue_com/
cd codes
python3 quickstart_uploadpng.py $png $folder
cd
done
fi

cd
rm -rf 'status_'$hour'.txt'
rm -rf *_png



#python3 quickstart.py --noauth_local_webserver

exit 0
