
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint, randrange
import datetime
# import psutil
import os



def exe():



   driver = webdriver.Firefox()

   for b in range(0,1000000):
                driver.delete_all_cookies()
                driver.get("http://technews928.blogspot.com/2018/07/traffic.html?utm_source=gcp6&utm_medium=firefoxtest4&utm_campaign=Github-test")


while True:
  exe()
