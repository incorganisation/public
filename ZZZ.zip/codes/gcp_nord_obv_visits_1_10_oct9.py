


import random
import selenium
import os


from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle
import os

def exe(LP,leakage,ps,sleep,nu_s):
        usr_agnt_mobile=[
"Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko; googleweblight) Chrome/38.0.1025.166 Mobile Safari/535.19",
"Mozilla/5.0 (Linux; U; Android 4.0.4; pt-br; MZ608 Build/7.7.1-141-7-FLEM-UMTS-LA) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30",
"Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/LMY48B ) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android-4.0.3; en-us; Galaxy Nexus Build/IML74K) AppleWebKit/535.7 (KHTML, like Gecko) CrMo/16.0.912.75 Mobile Safari/535.7",
"Mozilla/5.0 (Linux; U; Android-4.0.3; en-us; Xoom Build/IML77) AppleWebKit/535.7 (KHTML, like Gecko) CrMo/16.0.912.75 Safari/535.7",
"Mozilla/5.0 (Linux; Android 5.1.1; Nexus 5 Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.65 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.4.2; zh-cn; GT-I9500 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.0 QQ-URL-Manager Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android; 4.1.2; GT-I9100 Build/000000) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1234.12 Mobile Safari/537.22 OPR/14.0.123.123",
"Mozilla/5.0 (Linux; U; Android 2.3.6; en-us; LG-L38C Build/GRK39F) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1 MMS/LG-Android-MMS-V1.0/1.2",
"Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-G360T1 Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.3 Chrome/38.0.2125.102 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG SM-G900T Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.6 Chrome/28.0.1500.94 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.2; fr-fr; Desire_A8181 Build/FRF91) App3leWebKit/53.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; LGMS500 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; LGMS769 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-G550T1 Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/44.0.2403.133 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG-SM-G900A Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.6 Chrome/28.0.1500.94 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 7.0; LGMS210 Build/NRD90U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.3.6; en-gb; GT-S5830i Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; Android 4.4.2; LG-F180L Build/KOT49I.F180L30b) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36"
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG SM-N900T Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.5 Chrome/28.0.1500.94 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.3.6; en-us; LGL35G/V100) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.3; he-il; GT-I9300 Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; DROID RAZR Build/9.8.2O-72_VZW-16) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G955U Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/6.2 Chrome/56.0.2924.87 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G955U Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/5.4 Chrome/51.0.2704.106 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.4.2; id; SM-G900 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/9.9.2.467 U3/0.8.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900F Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.4; en-us; LGL34C/V100 Build/KRT16S.L34CV10c) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.2 Chrome/30.0.1599.103 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 2.3.6; en-gb; GT-S5360 Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
"Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; LGMS323 Build/KOT49I.MS32310b) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.1599.103 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G950U Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/6.2 Chrome/56.0.2924.87 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android 4.1.2; en-us; LG-LG730 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; U; Android 6.0.1; en-US; SM-G920F Build/LMY47X) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/10.10.0.796 U3/0.8.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; U; Android 4.1.2; he-il; GT-I9300 Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
"Mozilla/5.0 (Linux; Android 6.0.1; SM-J700F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-A500F Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/44.0.2403.133 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; Android 4.4.2; en-us; SAMSUNG SM-G900P Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.6 Chrome/28.0.1500.94 Mobile Safari/537.36"
]

#-------------------------------change chrome UA------------------------------
        opts = Options()
        # opts.add_argument("headless")
        # opts.add_argument("no-sandbox")

        # ext1 = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,30)) + '.zip'
        # ext2 = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(41,50)) + '.zip'
        # ext = random.choice([ext1,ext2])
        # opts.add_extension(ext)
        # ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,160)) + '.zip'
        # opts.add_extension(ext)

        # ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(41,50)) + '.zip'
        # opts.add_extension(ext)

        # opts = Options()
        # opts.add_extension(ext)
        # ext1 = '/home/prafful/codes/' + 'dcoxy' + str(randint(1,10)) + '.zip'
        # ext2 = '/home/prafful/codes/' + 'dcoxy' + str(randint(41,50)) + '.zip'
        # ext = random.choice([ext1,ext2])
        # opts.add_extension(ext)   
        
     
        # ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,160)) + '.zip'

        
        # nords = [

        #     'nord_sak_kh2_indonesia_id1.zip',
        #     'nord_sak_kh2_indonesia_id2.zip',
        #     'nord_sak_kh2_indonesia_id3.zip',
        #     'nord_sak_kh2_indonesia_id4.zip',
        #     'nord_sak_kh2_indonesia_id6.zip',

        # ]

        # ext = random.choice(nords)  



        nords = [

            'nord_sak_kh2_india_in17.zip',        
            'nord_sak_kh2_india_in18.zip',        
            # # 'nord_sak_kh2_th2.zip', 
            # # 'nord_sak_kh2_th3.zip',

            'nord_sak_india_in17.zip',
            'nord_sak_india_in18.zip',
            # 'nord_sak_th2.zip',
            # 'nord_sak_th3.zip',

            'nord_adi_india_in17.zip', 
            'nord_adi_india_in18.zip', 
            # 'nord_adi_th2.zip', 
            # 'nord_adi_th3.zip', 

            'nord_praf_india_in17.zip', 
            'nord_praf_india_in18.zip', 
            # 'nord_praf_th2.zip', 
            # 'nord_praf_th3.zip', 

            'nord_priceless_india_in17.zip', 
            'nord_priceless_india_in18.zip', 


            'nord_girwar_india_in17.zip',
            'nord_girwar_india_in18.zip',
            # 'nord_girwar_th2.zip',
            # 'nord_girwar_th3.zip',

            'nord_pub_india_in17.zip',
            'nord_pub_india_in18.zip',
            # 'nord_pub_th2.zip',
            # 'nord_pub_th3.zip',

            'nord_adops_india_in17.zip',
            'nord_adops_india_in18.zip',
            # 'nord_adops_th2.zip',
            # 'nord_adops_th3.zip',

            'nord_saras9422_india_in17.zip',
            'nord_saras9422_india_in18.zip',
            # 'nord_saras9422_th2.zip',
            # 'nord_saras9422_th3.zip',
            'nord_praf10_india_in17.zip',
            'nord_praf10_india_in18.zip',

            'nord_prafg10_india_in17.zip',
            'nord_prafg10_india_in18.zip',

            'nord_chirag_india_in17.zip',
            'nord_chirag_india_in18.zip',
            
            'nord_irn9422_india_in17.zip',
            'nord_irn9422_india_in18.zip',
            

                

            'nord_sak_kh2_india_in13.zip',  'nord_sak_kh2_india_in15zip', 'nord_sak_kh2_india_in19zip', 


            'nord_sak_india_in13.zip', 'nord_sak_india_in15.zip','nord_sak_india_in19.zip',


            'nord_adi_india_in13.zip', 'nord_adi_india_in15.zip','nord_adi_india_in19.zip',


            'nord_praf_india_in13.zip', 'nord_praf_india_in15.zip','nord_praf_india_in19.zip',


            'nord_priceless_india_in13.zip', 'nord_priceless_india_in15.zip','nord_priceless_india_in19.zip',


            'nord_girwar_india_in13.zip', 'nord_girwar_india_in15.zip','nord_girwar_india_in19.zip',


            'nord_pub_india_in13.zip', 'nord_pub_india_in15.zip','nord_pub_india_in19.zip',


            'nord_adops_india_in13.zip', 'nord_adops_india_in15.zip','nord_adops_india_in19.zip',


            'nord_saras9422_india_in13.zip', 'nord_saras9422_india_in15.zip','nord_saras9422_india_in19.zip',


            'nord_praf10_india_in13.zip', 'nord_praf10_india_in15.zip','nord_praf10_india_in19.zip',


            'nord_prafg10_india_in13.zip', 'nord_prafg10_india_in15.zip','nord_prafg10_india_in19.zip',


            'nord_chirag_india_in13.zip', 'nord_chirag_india_in15.zip','nord_chirag_india_in19.zip',


            'nord_irn9422_india_in13.zip', 'nord_irn9422_india_in15.zip','nord_irn9422_india_in19.zip',


        

        ]

        ext = random.choice(nords)  


        opts.add_extension(ext)        


        opts.add_argument("user-agent="+ usr_agnt_mobile[randint(0,len(usr_agnt_mobile)-1)])
        driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver',chrome_options=opts)
        driver.set_window_size(360,640)
#main url .........
        driver.get(LP)
        time.sleep(sleep)
        curl_main=driver.current_url
        time.sleep(sleep)
        driver.get(leakage)
        time.sleep(sleep)
        curl_leaks=driver.current_url
        time.sleep(sleep)
        for nu in range(nu_s):
            for i in range(ps):
                driver.get(curl_main)
                time.sleep(sleep)
# leakage url ..........
            for i in range(ps):
                driver.get(curl_leaks)
                time.sleep(sleep)
#        print(1)
        driver.close()
        driver.quit()
 
 
while True:
    try:
        exe("https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=380;d=20;w=1;h=1","https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=381;d=20;w=1;h=1",randint(1,5),randint(1,2),randint(9,10))
        time.sleep(3)
    except:
        continue





# <script type="text/javascript">window.location.href = "https://photogallery.tamil.samayam.com/?utm_source=organic&utm_medium=banner&utm_campaign=Tamil_Referral" </script>

# <script type="text/javascript">window.location.href = "https://photogallery.tamil.samayam.com/?utm_source=OptimiseMediaAugust&utm_medium=Referral_1136874&utm_campaign=Tamil_Referral" </script>

