from __future__ import print_function
from googleapiclient.discovery import build
from httplib2 import Http
from oauth2client import file, client, tools
from apiclient.http import MediaFileUpload
from apiclient import http
import os
import subprocess
import sys

#from oauth2client import storage


# If modifying these scopes, delete the file token.json.
SCOPES = 'https://www.googleapis.com/auth/drive'

def main():
    """Shows basic usage of the Drive v3 API.
    Prints the names and ids of the first 10 files the user has access to.
    """
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    global drive_service
    store = file.Storage('token.json')
    creds = store.get()
    if not creds or creds.invalid:
        flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
        creds = tools.run_flow(flow, store)
    drive_service = build('drive', 'v3', http=creds.authorize(Http()))

    # Call the Drive v3 API
    results = drive_service.files().list(
        pageSize=20, fields="nextPageToken, files(id, name)").execute()
    items = results.get('files', [])

    if not items:
        print('No files found.')
    else:
        print('Files:')
        for item in items:
            print(u'{0} ({1})'.format(item['name'], item['id']))

    return drive_service
if __name__ == '__main__':
    main()



def createfolder(foldername,mimetype):
	global folder_id
	file_metadata = {
    		'name': 'Global_screenshots',
   		 'mimeType': 'application/vnd.google-apps.folder'}
	file = drive_service.files().create(body=file_metadata,
                                    fields='id').execute()
	folder_id = file.get('id')
	Folderpath = os.path.join('/home/adops_increvenue_com/','folderid.txt')
	exists = os.path.isfile(Folderpath)
	if exists:
		with open(Folderpath,'a') as f:
			f.write("%s"%folder_id)
			f.close
	else:
		with open(Folderpath,'w+') as f:
			f.write("%s \n"%folder_id)
			f.close()
#	print('Folder ID: %s'%(folderid))
	return folder_id


foldername = str(sys.argv[1])
createfolder(foldername,'application/vnd.google-apps.folder')
