import random
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle
import os

def traffic_bot(S,BR,PS,TOS,sleep,urls,cName,fName):
    for i in range(1,210):
        print i;
        opts = Options()
 #       ext = '/Users/adityasaraswat/Desktop/increv_rnd/chirag/dcoxyzips/dcoxy' + str(i) + '.zip'
        ext = '/home/adops_increvenue_com/codes/dcoxy' + str(i) + '.zip'
        opts.add_extension(ext)
        time.sleep(1)
        driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver',chrome_options=opts)
#        driver = webdriver.Chrome(executable_path='/Users/adityasaraswat/Desktop/increv_rnd/Lovish/chromedriver',chrome_options=opts)
        time.sleep(1);
        driver.get("https://autocarzoom.blogspot.com/?utm_source="+str(i)+"&utm_medium="+str(i))
        time.sleep(3);
        
        driver.delete_all_cookies()
        driver.close()

iteration=str(randint(0,100))
linking=[]
while(True):
    traffic_bot(200,20,8,300,1,linking,"cookies_"+iteration+"_","tc_"+iteration+".csv")





