import subprocess
import random
import selenium
import os

from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime,pickle
import os
def traffic_bot(S,BR,PS,TOS,sleep,LP,urls,cName,fName,path):
    usr_agnt_mobile=[
"Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko; googleweblight) Chrome/38.0.1025.166 Mobile Safari/535.19",
"Mozilla/5.0 (Linux; U; Android 4.0.4; pt-br; MZ608 Build/7.7.1-141-7-FLEM-UMTS-LA) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30",
"Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/LMY48B ) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36",
"Mozilla/5.0 (Linux; U; Android-4.0.3; en-us; Galaxy Nexus Build/IML74K) AppleWebKit/535.7 (KHTML, like Gecko) CrMo/16.0.912.75 Mobile Safari/535.7",
"Mozilla/5.0 (Linux; U; Android-4.0.3; en-us; Xoom Build/IML77) AppleWebKit/535.7 (KHTML, like Gecko) CrMo/16.0.912.75 Safari/535.7",
"Mozilla/5.0 (Linux; Android 5.1.1; Nexus 5 Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.65 Mobile Safari/537.36",

    ]
    for i in range(0,1):
        f=open(fName,'a')
        f.write("---------------------------------INSTANCE REBOOTED-----------------------------------\n")
        f.flush()
#-------------------------------change chrome UA------------------------------
        opts = Options()

        # ext =  'dcoxy' + str(randint(1,50)) + '.zip'
        # ext = '/home/adops_increvenue_com/dcoxyzips/' + 'dcoxy' + str(randint(1,50)) + '.zip'
        # ext1 = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,10)) + '.zip'
        # ext2 = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(41,80)) + '.zip'
        # ext = random.choice([ext1,ext2])
        # opts.add_extension(ext)
        
        ext = '/home/adops_increvenue_com/codes/' + 'dcoxy' + str(randint(1,200)) + '.zip'
        opts.add_extension(ext)

        opts.add_argument("user-agent="+ usr_agnt_mobile[randint(0,len(usr_agnt_mobile)-1)])

#---------------------------------change firefox UA------------------------------
#        profile = webdriver.FirefoxProfile()
#        profile.set_preference("general.useragent.override",usr_agnt_mobile[randint(0,len(usr_agnt_mobile)-1)])
#----------------------------------------- 0 BR code---------------------------------
        a=0;
        time_cookiearray=[];
        zero_ps=((100*PS-BR)/(100-BR))-1
        zero_tos=(TOS*100)/(100-BR)
        while(a<((S*(100-BR))/100) or len(time_cookiearray)>0):
            driver = webdriver.Chrome(executable_path=path,chrome_options=opts)
            driver.set_window_size(360,640)
            if(a<(S*(100-BR))/100):
                driver.get(LP);
                time.sleep(sleep);
#               driver.get_screenshot_as_file('google.png')
                time0=datetime.datetime.now();
                cookie0=cName+str(a)+".pkl" ;
                curl0=driver.current_url
                f.write('Count %s,Initial_0Br,%s\n'% (a,str(datetime.datetime.now())))
                f.flush()
                time_cookiearray.append((time0,cookie0,curl0))
                pickle.dump(driver.get_cookies(),open(cookie0,"wb"))
                driver.delete_all_cookies()
#-----------RESTORE COOKIE FOR PREV SESSION-------------------
            if((datetime.datetime.now()-time_cookiearray[0][0]).seconds>zero_tos):
                cookies = pickle.load(open(time_cookiearray[0][1],"rb"))
                for cookie in cookies:
                    new_cookie={}
                    new_cookie['name']=cookie['name']
                    new_cookie['value']=cookie['value']
                    driver.add_cookie(new_cookie)
#----------------------------OPEN LINKS FOR OLD PS-----------------------------
                for pss in range(zero_ps):
                    driver.get(time_cookiearray[0][2]);
                    time.sleep(sleep)
                f.write('Count %s,Final_0Br,%s\n'% (a,str(datetime.datetime.now())))
                f.flush()
#----------------------------DELETE USED COOKIE-------------------------------
                os.remove(time_cookiearray[0][1])
                del time_cookiearray[0];
                driver.delete_all_cookies();
            driver.close();
            driver.quit();
            a=a+1;
#---------------------------------100 BR code-------------------------------
        for a in range(0,(S*BR)/100):
            driver = webdriver.Chrome(executable_path=path,chrome_options=opts)
            driver.set_window_size(360,640)
            driver.delete_all_cookies();
            driver.get(LP);
            time.sleep(sleep);
            f.write('Count %s,Only_100Br,%s\n'% (a,str(datetime.datetime.now())));
            f.flush();
            driver.delete_all_cookies();
            driver.close();
            driver.quit();
#-----------------------Delete faaltu cookies-------------------------
        while (len(time_cookiearray)>0):
            try:
                os.remove(time_cookiearray[0][1]);
                del time_cookiearray[0];
            except:
                continue
utm=""
home_dir = (subprocess.check_output("sudo echo $HOME", shell=True)).strip('\n')
path = home_dir + '/chromedriver'
url="http://newstrend247.com/index1.php/~https://technews928.blogspot.com/2018/07/lc-2.html?utm_source=gcp-13&utm_medium=iowa&utm_campaign=Oct_2018"
iteration=str(randint(0,1000000))
linking=[url,url,url,url,url]
while(True):
    traffic_bot(200,20,8,300,1,url,linking,"cookies_"+iteration+"_","tc_"+iteration+".csv",path)


# import subprocess, os
# path = (subprocess.check_output("echo $HOME", shell=True)).strip('\n')