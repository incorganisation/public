import random
import time
import re
#import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
#import requests
#from bs4 import BeautifulSoup
from selenium.webdriver.chrome.options import Options
from random import randint
import os
import zipfile
#from python_anticaptcha.NoCaptchaTaskProxyless import NoCaptchaTaskProxyless
from python_anticaptcha import AnticaptchaClient, NoCaptchaTaskProxylessTask

def a():
        api_key = "39678ad5d61115f4f5ca84623c96784f" 
        site_key = '6Lfs7skUAAAAACb1bVrb-aavhAGch_ICsLV1MQ1I'  # grab from site
        url = 'http://mustreadnew.com/2145-2/'
        client = AnticaptchaClient(api_key)
        task = NoCaptchaTaskProxylessTask(url, site_key)
        job = client.createTask(task)
        job.join();
        print job.get_solution_response()
        return (job.get_solution_response())


while True:
        print "in while"
        a();
