from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys


url = "https://saxp.zedo.com/jsc/sxp2/ff2.html?n=3711;c=872;d=20;w=1;h=1"

for i in range(0,1000000):
    driver = webdriver.Chrome()
    driver.get(url)
    time.sleep(1)
    #driver.find_element_by_partial_link_text('CHEER').Send_Keys(Keys.ENTER)
    button = WebDriverWait(driver, 80).until(EC.presence_of_element_located((By.ID, "btn-counter")))
    button.find_element_by_tag_name("img").click()

    time.sleep(2)
    driver.quit()
    time.sleep(3)
