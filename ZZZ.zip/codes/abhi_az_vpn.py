import random
import selenium
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime

hostname="178.128.168.134"
port="3128"

while (True):
    chrome_options = webdriver.ChromeOptions()
    #chrome_options.add_argument('--proxy-server=%s' % hostname + ":" + port)
    chrome_options.add_argument('--no-sandbox')
    driver = webdriver.Chrome(executable_path='/root/chromedriver',chrome_options=chrome_options)
    driver.get("https://diveshkapoor.blogspot.com?utm_source=microhostcitytest")
    time.sleep(1)
    driver.close()
    driver.quit()

