NOI='noi.txt'
rm -rf $NOI

gcloud compute instances list |wc -l >> /home/adops_increvenue_com/noi.txt
exit 0
