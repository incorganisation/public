import random
import selenium
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime

hostname="198.199.85.139"
port="3128"

while (True):
  #  chrome_options = webdriver.ChromeOptions()
 #   chrome_options.add_argument('--proxy-server=%s' % hostname + ":" + port)
    driver = webdriver.Chrome(executable_path='/home/adops_increvenue_com/chromedriver')#,chrome_options=chrome_options)
    driver.get("http://greatlovers942.blogspot.com/?utm_source=1&utm_medium=1")
    driver.get("https://www.firstpost.com/")
    time.sleep(1)
    driver.close()
    driver.quit()


    
    
    
