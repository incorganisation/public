import csv
import os
import subprocess
import math
from datetime import date
from datetime import time
from datetime import datetime


def club_packets(s1,br1,ps1,tos1,s2,br2,ps2,tos2):
    clubbed=[0,0,0,0];
    clubbed[0]=s1+s2;
    if (s1+s2==0):
        clubbed[1]=0
        clubbed[2]=0
        clubbed[3]=0
    else:
        clubbed[1]=((br1*s1)+(br2*s2))/(s1+s2)
        clubbed[2]=((ps1*s1)+(ps2*s2))/(s1+s2)
        clubbed[3]=((tos1*s1)+(tos2*s2))/(s1+s2)
    return clubbed


def finalfile(filename):
       data=[0,0,0,0];
       file=open(filename,"r")
       for line in file:
               line=line[:-1].split(",")
               data=club_packets(data[0],data[1],data[2],data[3],float(line[0]),float(line[1]),float(line[2]),float(line[3]));
       file.close();
       return (data)


#--------------------------------------IMAGE DECLARATION-----------------------
# ---------PRE EMPTIVE COST-----------

s16xl=0.16/60
s8xl=0.08/60
s4xl=0.04/60
s2xl=0.02/60

group01 = ["git-gcp-only-image-name-gcp-01-4x", s4xl]
group05 = ["git-gcp-only-image-name-gcp-05-2x", s2xl]
group12 = ["git-gcp-only-image-name-gcp-12-8x-devops", s8xl]
group13 = ["git-gcp-only-image-name-gcp-13-8x-devops", s8xl]
group14 = ["git-gcp-only-image-name-gcp-14-8x-devops", s8xl]
group15 = ["git-gcp-only-image-name-gcp-15-8x-devops", s8xl]
group16 = ["git-gcp-only-image-name-gcp-16-8x-devops", s8xl]
group18 = ["git-gcp-only-image-name-gcp-18-8x-devops", s8xl]
group21 = ["git-gcp-only-image-name-gcp-21-8x-devops", s8xl]
group22 = ["git-gcp-only-image-name-gcp-22-8x-devops", s8xl]
group23 = ["git-gcp-only-image-name-gcp-23-8x-devops", s8xl]
group24 = ["git-gcp-only-image-name-gcp-24-8x-devops", s8xl]


total_available_instances = 1000  # TOTAL NO. TO SHOOT UP


#------------------------------------------DATE - TIME FNS--------------------------------------------------
date_today = subprocess.check_output("TZ=Asia/Calcutta date +%Y-%m-%d", shell=True)
date_today = str(date_today.decode())
date_today = date_today.strip('\n')
print("date_today: {}\n".format(date_today))

stats_file = open(date_today+'~stats.txt', "a")

time_now = subprocess.check_output("TZ=Asia/Calcutta date +%H%M", shell=True)
time_now = int(time_now.decode())
print("time now: {}\n".format(time_now))
# stats_file.write("time now: {}\n".format(time_now))


# stats_file.write("date_today: {}\n".format(date_today))

hourtime_now = subprocess.check_output("TZ=Asia/Calcutta date +%H", shell=True)
hourtime_now = int(hourtime_now.decode())
print("hourtime_now: {}\n".format(hourtime_now))
# stats_file.write("hourtime_now: {}\n".format(hourtime_now))

previous_hourtime_now = int(hourtime_now)-1


# timestamp_file = open('timestamp.txt', 'r')
# timestamp_current = timestamp_file.read()
# print("timestamp_current: ".format(timestamp_current))
# stats_file.write("timestamp_current: ".format(timestamp_current))

with open('/home/adops_increvenue_com/timestamp_log.txt') as f:
    data = f.readlines()

timestamp_current = data[-1]
timestamp_current = timestamp_current.strip('\n')
timestamp_previous = data[-2]
timestamp_previous = timestamp_previous.strip('\n')

if (timestamp_previous == timestamp_current): # sometimes same timestamp is logged twice
    timestamp_previous = data[-3]
    timestamp_previous = timestamp_previous.strip('\n')

timestamp_current_int=int(timestamp_current.replace(':',''))
timestamp_previous_int=int(timestamp_previous.replace(':',''))

# tail = data[-10:]
print("timestamp_current: {}\n ".format(timestamp_current))
# stats_file.write("timestamp_current: {}\n ".format(timestamp_current))
print("timestamp_current: {}\n ".format(timestamp_current_int))
# stats_file.write("timestamp_current: {}\n ".format(timestamp_current_int))
print("timestamp_previous: {}\n ".format(timestamp_previous))
# stats_file.write("timestamp_previous: {}\n ".format(timestamp_previous))
print("timestamp_previous: {}\n".format(timestamp_previous_int))
# stats_file.write("timestamp_previous: {}\n".format(timestamp_previous_int))

def tymstmp(t):
    return (str(t)+":00")

#------------------------------------------------MAKE ACTIONS FILE USING TEXTQL---------------------------------------------------------
#group_name , code , cap , speed , br , ps , tos , st , et

# TO BE CALCULATED - SPEED, BR, TOS, PS
# TO BE PICKED LATEST - CAP , ST, ET , DATE TODAY , TIMESTAMP
# INDEX - code
# PANGA - group name

#HEADER - group_name , code , cap , speed , br , ps , tos , st , et , date_today , timestamp

# texqlpath_clubcsv= "$HOME/inc-logs/" + date_today +"/"+ str(hourtime_now)+"/"
texqlpath_clubcsv= "$HOME/inc-logs/" + date_today +"/"+ str(timestamp_current)+"/"

# @worked
# os.system("""textql -header -sql "    SELECT          group_name,     code,     cap,     SUM(speed) as impperhour,     SUM(speed * br)/(SUM(speed)+1) as brperhour,     SUM(speed * ps)/(SUM(speed)+1) as psperhour,     SUM(speed * tos)/(SUM(speed)+1) as tosperhour,     st,     et,     date_today,    timestamp, sd, ed   WHERE     date_today = '""" + date_today +"""' AND      timestamp > '"""+ tymstmp(timestamp_previous) + """' AND timestamp < '"""+ tymstmp(timestamp_current) + """'     GROUP BY code      "      """ + texqlpath_clubcsv + """timestamp_data.csv > """ + texqlpath_clubcsv + """actions.txt"""  )
# os.system("""textql -header -sql "    SELECT          group_name,     code,     cap,     SUM(speed) as impperhour,     SUM(speed * br)/(SUM(speed)+1) as brperhour,     SUM(speed * ps)/(SUM(speed)+1) as psperhour,     SUM(speed * tos)/(SUM(speed)+1) as tosperhour,     st,     et,     date_today,    timestamp, sd, ed   WHERE     date_today = '""" + date_today +"""' AND      timestamp > '"""+ tymstmp(timestamp_previous) + """' AND timestamp < '"""+ tymstmp(timestamp_current) + """'     GROUP BY code      "      """ + texqlpath_clubcsv + """timestamp_data.csv > """ + texqlpath_clubcsv + """actions.txt"""  )

# os.system("""textql -header -sql "    SELECT          group_name,     code,     cap,     SUM(speed) as impperhour,     SUM(speed * br)/(SUM(speed)+1) as brperhour,     SUM(speed * ps)/(SUM(speed)+1) as psperhour,     SUM(speed * tos)/(SUM(speed)+1) as tosperhour,     st,     et,     date_today,    timestamp, sd, ed   WHERE     date_today = '""" + date_today +"""'      GROUP BY code      "      """ + texqlpath_clubcsv + """timestamp_data.csv > """ + texqlpath_clubcsv + """actions.txt"""  )
os.system("""textql -header -sql "    SELECT          group_name,     code,     cap,     SUM(speed) as impperhour,     SUM(speed * br)/(SUM(speed)+1) as brperhour,     SUM(speed * ps)/(SUM(speed)+1) as psperhour,     SUM(speed * tos)/(SUM(speed)+1) as tosperhour,     st,     et,     date_today,    timestamp WHERE     date_today = '""" + date_today +"""'  AND      timestamp > '"""+ tymstmp(timestamp_previous) + """' AND timestamp < '"""+ tymstmp(timestamp_current) + """'       GROUP BY code      "      """ + texqlpath_clubcsv + """timestamp_data.csv > """ + texqlpath_clubcsv + """actions.txt"""  )

# os.system("""textql -header -sql "    SELECT          group_name,     code,     cap,     SUM(speed) as impperhour,     SUM(speed * br)/(SUM(speed)+1) as brperhour,     SUM(speed * ps)/(SUM(speed)+1) as psperhour,     SUM(speed * tos)/(SUM(speed)+1) as tosperhour,     st,     et,     date_today,    timestamp WHERE     date_today = '2018-10-18'  AND      timestamp > '18:12:00' AND timestamp < '19:12:00'       GROUP BY code      "      """ + texqlpath_clubcsv + """timestamp_data.csv > """ + texqlpath_clubcsv + """actions.txt"""  )





#------------------------------------------------------FIND TOTAL RUNNING INSTANCES----------------------------------------------------

os.system("""sudo gcloud compute instance-groups managed list --filter="zone:('asia-south1-b')" --sort-by="~SIZE" > instance_groups.txt""")
os.system("grep -Eo ' [0-9]{1,4} ' instance_groups.txt >  instances_in_instance_groups.txt")
total_double_sum = subprocess.check_output("awk '{SUM += $1} END { print SUM }'  instances_in_instance_groups.txt ", shell=True)
total_double_sum = int(total_double_sum.decode())
total_running_instances = int(total_double_sum / 2 )
print("total_running_instances: {}\n".format(total_running_instances))
# stats_file.write("total_running_instances: {}\n".format(total_running_instances))

max_instances_possible = total_available_instances - total_running_instances
print("max_instances_possible: {}\n".format(max_instances_possible))
# stats_file.write("max_instances_possible: {}\n".format(max_instances_possible))


stats_file.close()


#---------------------------
stats_file = open(date_today+'~stats.txt', "a")
# stats_file.write("%s,%s,%s,%s\n"%(str(current_speed),str(br),str(ps),str(tos)))

print(" \n ===================== Latest Timestamp based autoscaling ======================")
stats_file.write("\n ===================== Latest Timestamp based autoscaling ====================== ")
stats_file.write("time now: {}\n".format(time_now))
stats_file.write("date_today: {}\n".format(date_today))
stats_file.write("hourtime_now: {}\n".format(hourtime_now))
stats_file.write("timestamp_current: {}\n ".format(timestamp_current))
# stats_file.write("timestamp_current: {}\n ".format(timestamp_current_int))
stats_file.write("timestamp_previous: {}\n ".format(timestamp_previous))
# stats_file.write("timestamp_previous: {}\n".format(timestamp_previous_int))
stats_file.write("total_running_instances: {}\n".format(total_running_instances))
stats_file.write("max_instances_possible: {}\n".format(max_instances_possible))

stats_file.close()
#------------------------------------------------------PROCESS ACTION FILE AND IG UP DOWN ----------------------------------------------


with open('/home/adops_increvenue_com/inc-logs/' + date_today + '/' + str(timestamp_current)+'/actions.txt') as csv_file:
# with open('/home/chirag/inc-logs/' + date_today + '/' + str(hourtime_now-1)+'/actions.txt') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
            stats_file = open(date_today+'~stats.txt', "a")

            print("======================= Next Campaign ====================")
            stats_file.write("======================= Next Campaign ====================\n")

            instance_group_dummy_name    = row[0]
            # instance_group_name          = 'group01'
            instance_group_info          = eval(instance_group_dummy_name)
            instance_group_name          = instance_group_info[0]
            instance_group_cost          = instance_group_info[1]
            code_name                    = row[1]
            Zedo_cap                     = int(row[2])
            current_speed                = int(row[3])
            br                           = float(row[4])
            ps                           = float(row[5])
            tos                          = float(row[6])
            start_time                   = int(row[7])
            end_time                     = int(row[8])
            # date_today                   = row[9]
            # timestamp                    = row[10]

            print("code_name: {}\n".format(code_name))
            stats_file.write("code_name: {}\n".format(code_name))

#------------------------------ALL DAY STATS TOTAL ( WRITE AND SUM )------------------------------

            total_imp_file = open(date_today+'~'+instance_group_name +'~'+  code_name + '.txt', "a")
            total_imp_file.write("%s,%s,%s,%s\n"%(str(current_speed),str(br),str(ps),str(tos)))
            print("Number of impressions delivered in last duration: {}\n".format(current_speed))
            stats_file.write("Number of impressions delivered in last duration: {}\n".format(current_speed))
            print("br: {}\n".format(br))
            stats_file.write("br: {}\n".format(br))
            print("ps: {}\n".format(ps))
            stats_file.write("ps: {}\n".format(ps))
            print("tos: {}\n".format(tos))
            stats_file.write("tos: {}\n".format(tos))
            total_imp_file.close()

            total_imp_delivered = 0
            with open(date_today+'~'+instance_group_name +'~'+  code_name + '.txt', 'r') as imp_file:
                    for line in imp_file:
                        line= line[:-1].split(",")
                        total_imp_delivered += int(line[0])
                    print("total_imp_delivered_perday_tillnow: {}\n".format(total_imp_delivered))
                    stats_file.write("total_imp_delivered_perday_tillnow: {}\n".format(total_imp_delivered))
            total_imp_file.close()

            finalfile(date_today+'~'+instance_group_name +'~'+  code_name + '.txt')

#------------------------------printing--------------------------

            print("total_imp_delivered_perday_tillnow: {}\n".format(total_imp_delivered))
            stats_file.write("total_imp_delivered_perday_tillnow: {}\n".format(total_imp_delivered))

            print("instance_group_name: {} \n ".format(instance_group_name))
            stats_file.write("instance_group_name: {}\n ".format(instance_group_name))
            print("Zedo_cap: {}\n ".format( Zedo_cap))
            stats_file.write("Zedo_cap: {}\n ".format( Zedo_cap))
            print("total_imp_delivered_perday_tillnow: {}\n".format(total_imp_delivered))
            stats_file.write("total_imp_delivered_perday_tillnow: {}\n".format(total_imp_delivered))
            # print("current_speed: {}\n".format(current_speed))
            # stats_file.write("current_speed: {}\n".format(current_speed))
            # speed_required = ((Zedo_cap - total_imp_delivered) * 100.0) / (end_time - start_time)

#-----------------------------what actions to take --------------------------------

            if(time_now < start_time or time_now > end_time):
                print("No need to run this campaign for now")
                stats_file.write("No need to run this campaign for now\n")
            else:

                if (timestamp_current_int < timestamp_previous_int):
                    print("Taking start time from 00:01")
                    stats_file.write("Taking start time from 00:01\n")
                    timestamp_previous = '00:01'
                    timestamp_previous_int = 1
                    print("timestamp_previous: {}\n".format(timestamp_previous))
                    stats_file.write("timestamp_previous: {}\n".format(timestamp_previous))
                    print("timestamp_previous: {}\n".format(timestamp_previous_int))
                    stats_file.write("timestamp_previous: {}\n".format(timestamp_previous_int))
                elif (timestamp_previous_int == 0):
                    timestamp_previous_int = 1
                elif (timestamp_current_int == 0):
                    print("Midnight")
                    stats_file.write("Midnight")
                    # Do something here TODO
                else:
                    print("Timestamp log is Ok \n")
                    # stats_file.write("Timestamp log is Ok \n")


                os.system('sudo gcloud compute instance-groups managed list --filter="name=(' + instance_group_name + ')" > ' + instance_group_name + '.txt')
                current_no_of_instances_binary = subprocess.check_output("grep -Eo ' [0-9]{1,4} ' " + instance_group_name + ".txt | head -1 ", shell=True)
                # print("current_no_of_instances_binary: {}\n".format(current_no_of_instances_binary))
                # stats_file.write("current_no_of_instances_binary: {}\n".format(current_no_of_instances_binary))
                current_no_of_instances = int(current_no_of_instances_binary.decode())
                print("current_no_of_instances: {}\n".format(current_no_of_instances))
                stats_file.write("current_no_of_instances: {}\n".format(current_no_of_instances))
                # updated_no_of_instances = (current_no_of_instances) * math.ceil(speed_required / current_speed)

                # speed_required = ((Zedo_cap - total_imp_delivered) * 100.0) / ((end_time - time_now))
                # speed_required = ((Zedo_cap - total_imp_delivered) * 100.0) / (timestamp_current_int - timestamp_previous_int)
                # speed_required = (Zedo_cap - total_imp_delivered)  / ( end_time - timestamp_current_int)
                # speed_required =  float(((Zedo_cap - total_imp_delivered)  / ( end_time - timestamp_current_int)))

                # current_speed_pertimestamp = float((current_speed/(timestamp_current_int - timestamp_previous_int)))


                # print("speed_required: {}\n".format(speed_required))
                # stats_file.write("speed_required: {}\n".format(speed_required))
                # print("current_speed: {}\n".format(current_speed_pertimestamp))
                # stats_file.write("current_speed: {}\n".format(current_speed_pertimestamp))

                if ( total_imp_delivered > ( Zedo_cap * 0.95) ):
                    updated_no_of_instances = 0
                    print("impressions delivered are greater than 95%  of the zedo cap ")
                    stats_file.write("impressions delivered are greater than 95%  of the zedo cap \n")
                else:
                    if(current_no_of_instances == 0):
                        current_no_of_instances=1;

                    if (current_speed < 20):                    # This will prevent corrupted campaigns from scaling up unnecessarily
                        current_speed = 9999999999999999999999    # This will prevent it from  #TODO # Will improve this 
                        # TODO currently this will scale down buggy campaigns (which may not be required)

                    # print("### current_speed: {}".format(current_speed))
                    # stats_file.write("### current_speed: {} \n".format(current_speed))  
                    # print("### end_time: {}".format(end_time))
                    # stats_file.write("### end_time: {} \n".format(end_time))
                    # print("### end_time - timestamp_current_int: {}\n".format(end_time - timestamp_current_int))
                    # stats_file.write("### end_time - timestamp_current_int: {}\n".format(end_time - timestamp_current_int))
                    # print("### timestamp_current_int - timestamp_previous_int: {} \n".format(timestamp_current_int - timestamp_previous_int))
                    # stats_file.write("### timestamp_current_int - timestamp_previous_int: {}".format(timestamp_current_int - timestamp_previous_int))
                    # print("### float(current_speed/(timestamp_current_int - timestamp_previous_int)): {} \n".format(float(current_speed/(timestamp_current_int - 
                    # stats_file.write("### float(current_speed/(timestamp_current_int - timestamp_previous_int)): {} \n".format(float(current_speed/(timestamp_current_int - timestamp_previous_int))))
                    # updated_no_of_instances = math.ceil((current_no_of_instances ) * float((Zedo_cap - total_imp_delivered)  / ( end_time - timestamp_current_int)) / float(current_speed/(timestamp_current_int - timestamp_previous_int)))
                    updated_no_of_instances = math.ceil((current_no_of_instances ) * float((Zedo_cap - total_imp_delivered)  / ( end_time - timestamp_current_int)) / float(current_speed/(timestamp_current_int - timestamp_previous_int)))

                    print("updated_no_of_instances: {}\n".format(updated_no_of_instances))
                    stats_file.write("updated_no_of_instances: {}\n".format(updated_no_of_instances))

                    current_speed_pertimestamp = float((current_speed/(timestamp_current_int - timestamp_previous_int)))
                    print("current_speed_pertimestamp (impressions delivered in previous timestamp duration divided by duration in minutes): {}\n".format(current_speed_pertimestamp))
                    stats_file.write("current_speed_pertimestamp (impressions delivered in previous timestamp duration divided by duration in minutes): {}\n".format(current_speed_pertimestamp))
                    required_speed = float((Zedo_cap - total_imp_delivered)  / ( end_time - timestamp_current_int))
                    print("required_speed (impressions that need to be delivered by the EOD divided by remaining time) : {}\n".format(required_speed))
                    stats_file.write("required_speed (impressions that need to be delivered by the EOD divided by remaining time): {}\n".format(required_speed))


# import csv
# import os
# import subprocess
# import math
# from datetime import date
# from datetime import time
# from datetime import datetime

# current_no_of_instances = 100
# Zedo_cap           = 12000
# total_imp_delivered = 3000
# end_time = 2400
# timestamp_current_int = 1200
# current_speed = 1000
# timestamp_previous_int = 600

# updated_no_of_instances = math.ceil((current_no_of_instances ) * float((Zedo_cap - total_imp_delivered)  / ( end_time - timestamp_current_int)) / float((current_speed/(timestamp_current_int - timestamp_previous_int))))
# print("updated_no_of_instances: {}\n".format(updated_no_of_instances))
# stats_file.write("updated_no_of_instances: {}\n".format(updated_no_of_instances))


                    if (updated_no_of_instances >= max_instances_possible ):
                        updated_no_of_instances = math.ceil(max_instances_possible * 0.85)   # otherwise one campaign may block other campaigns from getting started
                        # print("updated_no_of_instances: " + str(updated_no_of_instances))
                        # stats_file.write("updated_no_of_instances: " + str(updated_no_of_instances))
                        print("max_instances_possible reached")  #print
                        stats_file.write("max_instances_possible reached \n")  #print

#------------------------- Max Cap based on Zedo cap----------------------------------------#
                    # TODO change the below code to switch/case statements
                    if (updated_no_of_instances >= 10 and Zedo_cap < 10000):
                        updated_no_of_instances = 10
                        print("Scaled down based on Zedo cap ")
                        stats_file.write("Scaled down based on Zedo cap \n")

                    if (updated_no_of_instances >= 50 and Zedo_cap < 100000):
                        updated_no_of_instances = 50
                        print("Scaled down based on Zedo cap ")
                        stats_file.write("Scaled down based on Zedo cap \n")


                    if (updated_no_of_instances >= 100 and Zedo_cap < 1000000):
                        updated_no_of_instances = 100
                        print("Scaled down based on Zedo cap ")
                        stats_file.write("Scaled down based on Zedo cap \n")


                    if (updated_no_of_instances >= 500):
                        updated_no_of_instances = 500
                        print("Scaled down")
                        stats_file.write("Scaled down \n")


                    if ( end_time == 5000 ):    # change this to end date later on TODO
                        updated_no_of_instances = 0
                        print("Stopping since it is End Date ")
                        stats_file.write("Stopping since it is End Date \n")

                    print("updated_no_of_instances: " + str(updated_no_of_instances))
                    stats_file.write("updated_no_of_instances: {}\n".format(updated_no_of_instances))
                    print("normalup")  #print
                    stats_file.write("normalup \n")  #print




                print("updated_no_of_instances: " + str(updated_no_of_instances))
                stats_file.write("updated_no_of_instances: {}\n".format(updated_no_of_instances))
                print("Total cost for next hour: {}\n".format(updated_no_of_instances * instance_group_cost))
                print("Total cost for previous timestamp: {}\n".format(current_no_of_instances * instance_group_cost * (timestamp_current_int - timestamp_previous_int)))
                stats_file.write("Total cost for next hour: {}\n".format(updated_no_of_instances * instance_group_cost))





                # os.system('gcloud compute instance-groups managed resize ' + instance_group_name + ' --size='+ str(int(updated_no_of_instances))+  ' --zone=asia-south1-b ')
                # os.system('gcloud compute instance-groups managed resize git-gcp-only-image-name-gcp-13-8x-devops --size='+ updated_no_of_instances+  ' --zone=asia-south1-b ')
                stats_file.write("===================== ---------------------------- ======================\n")

                stats_file.close()




