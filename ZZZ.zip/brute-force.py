import random
import selenium
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import Select
import time,traceback
from random import randint
import datetime
import string
import random

opts=Options()
opts.add_argument('--no-sandbox')
driver = webdriver.Chrome(executable_path='/root/chromedriver',chrome_options=opts)
while (True):
    try:
        #driver = webdriver.Chrome(executable_path='c:/users/divesh/downloads/chromedriver',chrome_options=opts)
        #driver.set_window_size(360,640)
        #url="https://push.aarth.net/?cid=RzcCJ"
        url= "https://push.aarth.net/?cid="+random.choice(string.ascii_uppercase)+random.choice(string.ascii_lowercase)+random.choice(string.ascii_lowercase)+random.choice(string.ascii_uppercase)+random.choice(string.ascii_uppercase)
        driver.get(url)
        time.sleep(2)
        #print(driver.current_url)
        c=driver.current_url
        out=open('outputfile.csv','a')
        out.write(driver.current_url +'\n')
        #driver.close()
        #driver.quit()
    except:
        continue




